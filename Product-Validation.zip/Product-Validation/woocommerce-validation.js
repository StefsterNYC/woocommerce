jQuery(document).ready(function ($) {
    // Create an error message container below the Publish button
    $('.editor-post-publish-button__button, #publish').after('<div id="required-fields-error" style="color: #d63638; margin-top: 5px;"></div>');

    function validateFields() {
        let errors = [];
        let missingFields = [];

        // Product Name
        if ($('#title').val().trim() === "") {
            errors.push("Add a name to the product");
            missingFields.push("Product Name");
        }

        // Category
        if ($('#product_catchecklist input:checked').length === 0) {
            errors.push("Select at least one category");
            missingFields.push("Category");
        }

        // Tags (either selected from list or manually added)
        let tagsSelected = $('#product_tagchecklist .selectit input:checked').length;
        let tagsAdded = $('#product_tag .tagchecklist span').length;
        if (tagsSelected === 0 && tagsAdded === 0) {
            errors.push("Add at least one tag");
            missingFields.push("Tags");
        }

        // Brand (If using a product brand taxonomy)
        if ($('#product_brandchecklist input:checked').length === 0) {
            errors.push("Select a brand");
            missingFields.push("Brand");
        }

        // Description
        if ($('#content').val().trim() === "") {
            errors.push("Add a product description");
            missingFields.push("Description");
        }

        // Main Image
        if (!$('#set-post-thumbnail img').length) {
            errors.push("Set a main product image");
            missingFields.push("Main Image");
        }

        // Price Validation (Ensuring it's a valid positive number)
        let price = $('#_regular_price').val().trim().replace(',', '.');
        if (price === "" || isNaN(price) || parseFloat(price) <= 0) {
            errors.push("Enter a valid price greater than 0");
            missingFields.push("Price");
        }

        // Get Publish button and error message container
        let publishButton = $('.editor-post-publish-button__button, #publish');
        let errorMessage = $('#required-fields-error');

        // If there are errors, disable publish and show message
        if (errors.length > 0) {
            publishButton.prop('disabled', true);
            errorMessage.html(
                '<p style="color: red; font-size: 17px; background-color: black; border: 5px solid red; padding: 10px; text-align: center;">' +
                '<strong><u>⚠️ You must fill in the following fields before publishing:</u></strong><br>' +
                '<span style="color: orange; font-size: 15px;"><strong>' +
                missingFields.map(field => `[ ${field} ]`).join(", ") +
                '</strong></span></p>'
            );
        } else {
            publishButton.prop('disabled', false);
            errorMessage.empty();
        }
    }

    // Run validation when certain fields change
    $('#title, #content, #_regular_price').on('input', validateFields);
    $('#product_catchecklist, #product_brandchecklist').on('change', validateFields);
    $('#product_tag .tagchecklist').on('DOMSubtreeModified', validateFields);

    // Observe changes to the featured image section
    const observer = new MutationObserver(() => validateFields());
    observer.observe(document.getElementById('set-post-thumbnail'), { childList: true, subtree: true });

    // Initial validation check when the page loads
    validateFields();
});