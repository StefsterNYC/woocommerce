<?php

function enqueue_woocommerce_field_validation_script($hook) {
    global $post;

    // Load only on WooCommerce product edit pages
    if (($hook === 'post.php' || $hook === 'post-new.php') && get_post_type($post) === 'product') {
        wp_enqueue_script(
            'woocommerce-field-validation',
            get_template_directory_uri() . '/js/woocommerce-validation.js',
            array('jquery'),
            '1.0',
            true
        );
    }
}
add_action('admin_enqueue_scripts', 'enqueue_woocommerce_field_validation_script');


function validate_woocommerce_product_fields($post_id, $post) {
    // Only validate products
    if ($post->post_type !== 'product') {
        return;
    }

    // Check if we're in an autosave or bulk edit scenario
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check user capabilities
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Array to hold errors
    $errors = [];

    // Product Name
    if (empty($_POST['post_title'])) {
        $errors[] = "Product Name is required.";
    }

    // Category
    if (empty($_POST['tax_input']['product_cat']) || !is_array($_POST['tax_input']['product_cat'])) {
        $errors[] = "At least one category is required.";
    }

    // Tags (Optional - You can enforce if needed)
    if (empty($_POST['tax_input']['product_tag']) || !is_array($_POST['tax_input']['product_tag'])) {
        $errors[] = "At least one tag is required.";
    }

    // Brand (If using a brand taxonomy)
    if (empty($_POST['tax_input']['product_brand']) || !is_array($_POST['tax_input']['product_brand'])) {
        $errors[] = "Brand selection is required.";
    }

    // Description
    if (empty($_POST['post_content'])) {
        $errors[] = "Product Description is required.";
    }

    // Featured Image (Checks if an image is set)
    if (!has_post_thumbnail($post_id)) {
        $errors[] = "A main product image is required.";
    }

    // Price
    $price = isset($_POST['_regular_price']) ? trim($_POST['_regular_price']) : '';
    if ($price === "" || !is_numeric($price) || floatval($price) <= 0) {
        $errors[] = "A valid price greater than 0 is required.";
    }

    // If there are errors, prevent publishing
    if (!empty($errors)) {
        wp_die(
            "<strong>Product could not be published due to the following errors:</strong><br><br>" .
            implode('<br>', $errors) .
            "<br><br><a href='" . esc_url(get_edit_post_link($post_id, 'redirect')) . "'>Go Back</a>",
            "Error: Missing Required Fields",
            ['response' => 400]
        );
    }
}
add_action('save_post', 'validate_woocommerce_product_fields', 10, 2);